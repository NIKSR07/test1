<?php

require('config.php');
include('pengesahan.php');

// Sediakan pembolehubah yang selamat
$guruid = htmlspecialchars($_SESSION['username'] ?? '');

// Gunakan null-coalescing (??) untuk elak ralat jika tiada 'tambah_id'
$pelajarid = htmlspecialchars($_GET['tambah_id'] ?? '');

// --- BAHAGIAN 1: PROSES PENAMBAHAN REKOD (INSERT) ---

if (isset($_POST['Submit'])) {

    // Kumpulkan data yang dihantar melalui borang (Guna nama yang sama dengan input name)
    $idpelajar_post = $_POST['IDPelajar'];
    $tarikh = $_POST['Tarikh'];
    $berat = $_POST['Berat'];
    $tinggi = $_POST['Tinggi'];
    $idguru_post = $_POST['IDGuru'];

    // ⚠️ KESELAMATAN: Gunakan Prepared Statement
    // Pastikan nama kolom dalam query adalah betul: Idpelajar, berat, tinggi, tarikh, Idguru
    $stmt = $con->prepare("INSERT INTO bmi (Idpelajar, berat, tinggi, tarikh, Idguru) VALUES (?, ?, ?, ?, ?)");
    
    // Bind parameter: Saya anggap semua String ('sssss')
    $stmt->bind_param("sssss", $idpelajar_post, $berat, $tinggi, $tarikh, $idguru_post);

    if ($stmt->execute()) {
        echo "<script>alert('Rekod BMI pelajar $idpelajar_post berjaya ditambah.');
        window.location='dashboard.php'</script>";
    } else {
        // Output ralat SQL untuk tujuan debugging jika skrin kosong
        echo "<script>alert('RALAT: Penambahan rekod gagal. Ralat: " . $stmt->error . "');
        window.location='dashboard.php'</script>";
    }
    
    $stmt->close();
}
else
{
// --- BAHAGIAN 2: PAPARAN BORANG (HTML) ---
?>
<!DOCTYPE html>
<html>
<head>
    <title>TAMBAH REKOD</title>
</head>
<body>
<center><h2>TAMBAH REKOD BARU BMI PELAJAR</h2>
<fieldset>

    <form action="tambah_bmi.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr>
                <td>No KP Pelajar</td>
                <td><input type="text" name="IDPelajar" readonly value="<?php echo $pelajarid; ?>"></td>
            </tr>
            <tr>
                <td>Berat (kg)</td>
                <td><input type="number" name="Berat" placeholder="Berat-kg" required autofocus min="1" step="0.1"></td>
            </tr>
            <tr>
                <td>Tinggi (cm)</td>
                <td><input type="number" name="Tinggi" placeholder="Tinggi-cm" required min="1" step="0.1"></td>
            </tr>
            <tr>
                <td>Tarikh</td>
                <td><input type="date" name="Tarikh" readonly value="<?php echo date("Y-m-d"); ?>" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="Submit" value="Tambah"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="hidden" name="IDGuru" value="<?php echo $guruid; ?>"></td>
            </tr>
        </table>
    </form>
<br>
<a href="dashboard.php"><input type="button" value="Dashboard Guru"></a> |
<a href="senarai_pelajar.php"><input type="button" value="Senarai Pelajar"></a>
</fieldset></center>
</body>
</html>
<?php 
}
?>