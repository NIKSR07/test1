<?php
// Sambung ke pangkalan data
require('config.php');
// Memastikan pengguna login terlebih dahulu
include('pengesahan.php');

// --- BAHAGIAN 1: PROSES KEMASKINI (UPDATE) ---

// Semak sama ada data telah dihantar melalui borang
if (isset($_POST['update'])) {
    // Pembolehubah untuk memegang data yang dihantar
    $idpelajar = $_POST['idpelajar'];
    $idbmi = $_POST['idbmi'];
    $berat = $_POST['berat'];
    $tinggi = $_POST['tinggi'];
    $tarikh = $_POST['tarikh'];

    // Gunakan Prepared Statement untuk keselamatan (elak SQL Injection)
    // Tanda soal (?) adalah placeholder untuk nilai
    $stmt = $con->prepare("UPDATE bmi SET berat=?, tinggi=?, tarikh=? WHERE idbmi=?");

    // 's' untuk string, 'i' untuk integer. Sesuaikan mengikut jenis data kolom anda.
    // Jika berat dan tinggi adalah integer, gunakan 'iiss'. Jika semua string, gunakan 'ssss'.
    // Saya anggap berat dan tinggi INT, idbmi dan tarikh STRING.
    $stmt->bind_param("sisi", $berat, $tinggi, $tarikh, $idbmi);

    // Laksanakan query
    if ($stmt->execute()) {
        // Papar mesej jika rekod sudah di update
        echo "<script>alert('Kemaskini maklumat berjaya!');
        window.location='dashboard.php'</script>";
    } else {
        // Papar mesej jika terdapat ralat
        echo "<script>alert('RALAT: Kemaskini maklumat GAGAL. Sila cuba lagi.');
        window.location='edit_bmi.php?kemaskini_id=$idbmi'</script>";
    }

    $stmt->close();
}

// --- BAHAGIAN 2: MENDAPATKAN DATA SEMASA UNTUK BORANG (SELECT) ---

// Dapatkan ID dari URL. Gunakan operator null-coalescing untuk elak ralat jika tiada ID.
$id = $_GET['kemaskini_id'] ?? null;

// Jika ID wujud, dapatkan data
if ($id) {
    // Gunakan Prepared Statement untuk SELECT
    $stmt_select = $con->prepare("SELECT idpelajar, berat, tinggi, tarikh FROM bmi WHERE idbmi=?");
    $stmt_select->bind_param("s", $id); // 's' kerana idbmi ialah String ('001')
    $stmt_select->execute();
    $result = $stmt_select->get_result();

    if ($result->num_rows > 0) {
        $res = $result->fetch_assoc();
        // Paparkan data semasa
        $idpelajar = $res['idpelajar'];
        $berat = $res['berat'];
        $tinggi = $res['tinggi'];
        $tarikh = $res['tarikh'];
    } else {
        // Jika ID tidak dijumpai
        echo "<script>alert('RALAT: ID rekod tidak dijumpai.');
        window.location='dashboard.php'</script>";
        exit;
    }

    $stmt_select->close();
} else {
    // Jika tiada ID dalam URL
    echo "<script>alert('RALAT: Tiada ID kemaskini yang diberikan.');
    window.location='dashboard.php'</script>";
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>KEMASKINI</title>
</head>
<body>
<center><h2>KEMASKINI MAKLUMAT BMI</h2>
<fieldset>
<form name="form1" method="post" action="edit_bmi.php">
    <table border="0">
    <tr>
    <td>No KP Pelajar</td>
    <td><input type="text" name="idpelajar" value="<?php echo htmlspecialchars($idpelajar);?>" readonly></td>
    </tr>

    <tr>
    <td>Berat (kg)</td>
    <td><input type="number" name="berat" value="<?php echo htmlspecialchars($berat);?>" required></td>
    </tr>

    <tr>
    <td>Tinggi (cm)</td>
    <td><input type="number" name="tinggi" value="<?php echo htmlspecialchars($tinggi);?>" required></td>
    </tr>

    <tr>
    <td>Tarikh</td>
    <td><input type="date" name="tarikh" value="<?php echo htmlspecialchars($tarikh);?>" required></td>
    </tr>

    <tr>
        <td><input type="hidden" name="idbmi" value="<?php echo htmlspecialchars($id);?>"></td>
        <td><input type="submit" name="update" value="Update"></td>
    </tr>
</table>
</form>
<br>
<a href="dashboard.php"><input type="button" value="Menu Guru"></a>
</fieldset>
</body>
</html>