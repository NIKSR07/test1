<?php
include 'config.php';


$id = $_GET['Idpelajar'];

$result = mysqli_query($con, "DELETE FROM pelajar WHERE Idpelajar='$id'");


if ($result) {

    echo "<script>alert('Rekod pelajar $id berjaya dipadam.');
    window.location='senarai_pelajar.php'</script>";
} else {

    echo "<script>alert('RALAT: Rekod pelajar $id GAGAL dipadam. Ralat SQL: " . mysqli_error($con) . "');
    window.location='senarai_pelajar.php'</script>";
}
?>