<?php

require('config.php');

include('pengesahan.php');

if(isset($_POST['Submit'])) {

	$idpelajar = $_POST['IDPelajar'];
	$nama = $_POST['Nama'];
	$jantina = $_POST['Jantina'];

	$result = mysqli_query($con, "INSERT INTO pelajar(IDPelajar,Nama,Jantina)
		VALUES('$idpelajar','$nama','$jantina')");

	echo "<script>window.location='senarai_pelajar.php'</script>";
}
else
{
?>

<!DOCTYPE html>
<html>
<head>
	<title>TAMBAH REKOD</title>
</head>
<body>
<center><h2>TAMBAH REKOD PELAJAR BARU</h2>
<fieldset>
	<form action="daftar_pelajar.php" method="post" name="form1">
		<table width="30%" border="0">
			<tr>
				<td>Nombor KP</td>
				<td>:<input type="text" name="IDPelajar" size="12"
					placeholder="No KP" required autofocus></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><width="400">:<input type="text" name="Nama" placeholder="Nama Penuh" requred autofocus></td>
			</tr>
			<tr>
				<td>Jantina</td>
				<td>
					<select name="Jantina" required autofocus>
					<option value="">--Pilih--</option>
					<option value="Lelaki">Lelaki</option>
					<option value="Perempuan">Perempuan</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="Submit" value="DAFTAR"></td>
			</tr>
		</table>
	</form>
<br><a href="dashboard.php"><input type="submit" name="submit" value="Dashboard Guru"></a> |
<a href="senarai_pelajar.php"><input type="submit" name="submit" value="Senarai Pelajar"></a>
</fieldset>
</center>
<?php
}
?>
</body>
</html>