<?php

require('config.php');

include('pengesahan.php');

$id=$_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>DASHBOARD GURU</title>
</head>
<body>
<center><h2>DASHBOARD GURU</h2>
<i>Gaya hidup yang cergas dan sihat sepanjang hayat</i></center>
<fieldset>
	
<table width="800" border="1" align="center">
	<tr><br><center>SENARAI NAMA SEMUA PELAJAR</center>
		<br>
		<td width="20" align="center"><b>Bil.</b></td>
		<td width="100" align="center"><b>Nom KP Pelajar</b></td>
		<td width="300" align="center"><b>Nama</b></td>
		<td width="20" align="center"><b>Jantina</b></td>
		<td width="200" align="center"><b>Tindakan</b></td>
	</tr>
<?php

$dataA = mysqli_query($con, "SELECT * FROM pelajar ORDER BY nama ASC");
$no=1;
	while ($infoA=mysqli_fetch_array($dataA)) {
	?>
	<tr>
		<!--panggil semula rekod ke dalam baris-->
		<td align="center"><?php echo $no;?></td>
		<td align="center"><?php echo $infoA['Idpelajar'];?></td>
		<td align="center"><?php echo $infoA['Nama'];?></td>
		<td align="center"><?php echo $infoA['Jantina'];?></td>
	<td>
		<!-- tambah pautan tambah BMI |Edit Pelajar| Hapus pelajar-->
		<a href="tambah_bmi.php?tambah_id=<?php echo $infoA['Idpelajar'];?>">Tambah BMI</a> |
		<a href="edit_pelajar.php?kemaskini_id=<?php echo $infoA['Idpelajar'];?>">Kemaskini </a> |
		<a href="hapus_pelajar.php?hapus_id=<?php echo $infoA['Idpelajar'];?>"
			onclick="return confirm('Anda Pasti?')">Hapus </a> 
	</td>
</tr>

<?php
$no++;
	}
	?>

</table>
<br>
<center><a href="dashboard.php"><input type="submit" name="submit" value="Menu Guru"></a> |
<a href="daftar_pelajar.php"><input type="submit" name="submit" value="Daftar Pelajar"></a>  |
<a href="logout.php"><input type="submit" name="submit" value="LOGOUT"></a>
</center>
</fieldset>
</body>
</html>