<?php

require('config.php');

session_start();
if(isset($_POST['username'])) {

	$username = $_POST['username'];

	$sql = "SELECT * FROM pelajar WHERE IDPelajar='$username'";

	$hasil = mysqli_query($con, $sql);


	if(mysqli_num_rows($hasil)){

		$_SESSION['username'] = $username;

		header("Location: pelajar_bmi.php");
	}else{

		echo "<script>alert('ID Pelajar salah');
		window.location='pelajar_login.php'</script>";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>SISTEM REKOD BMI PELAJAR</title>
	<center><h2>SISTEM REKOD BMI PELAJAR</h2>
</head>
<i> Gaya hidup yang cergas dan sihat sepanjang hayat</i></center>
<body>

<fieldset>
	
	<form method="POST">
<center>
	<p>Login pelajar</p>
	<label for="inputIDGuru">Nombor Kad Pengenalan Pelajar</label>
	<br>
	<br>
	<input type="text" name="username" placeholder="Nombor KP" size="12" required><br>
	<br>
	<button type="submit">Login</button>
</form>
</center>
</fieldset>

</body>
</html>