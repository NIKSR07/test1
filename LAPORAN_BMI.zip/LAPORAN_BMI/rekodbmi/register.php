<?php

require('config.php');

if(isset($_POST['username'])){
	
	$nama = $_POST['guru'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "INSERT INTO guru (IDGuru,Guru,Katalaluan)
	VALUES ('$username','$nama','$password')";


	$hasil = mysqli_query($con, $sql);


	if ($hasil){
	echo "<script>alert('ID Guru anda telah berjaya didaftarkan');
	window.location='index.php'></script>";
	}else{
		echo "<script>alert('ID Guru gagal didaftarkan');
		window.location='register.php'</script>";
	}
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>PENDAFTARAN ID GURU</title>
	<center><h2>SISTEM REKOD BMI PELAJAR</h2>
</head>
<i>Gaya hidup yang cergas dan sihat sepanjang haya</i></center>
<body>
<fieldset>
<center>
	<form method="POST">
		<p> Pendaftaran ID Guru Baru</p>
		<label for="inputidguru">ID Guru</label>
		<br>
		<input type="text" name="username" placeholder="Username" required>
		<br>
		<br>
		<label for="inputnama">Nama Guru</label>
		<br>
		<input type="text" name="guru" id="inputnama" placeholder="Nama Guru" required autofocus>
		<br>
		<br>
		<label for="inputpassword">Katalaluan</label><br>
		<input type="password" name="password" id="inputpassword" placeholder="Password" required>
		<br>
		<br>
		<button type="submit">Daftar</button>
		<br>
		<br>
		Jika anda sudah daftar ID Guru, Klik <a href="index.php">Login</a>
	</form>

</fieldset>
</body>
</html>