<?php

require('config.php');

include('pengesahan.php');

$id=$_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>DASHBOARD GURU</title>
</head>
<body>
<center>
<h2>DASHBOARD GURU</h2>
<i>Gaya Hidup yang cergas dan sihat sepanjang hayat</i>
<fieldset>
<b>SELAMAT DATANG:</b> <br>
	<?php
	$dataA=mysqli_query($con, "select * from guru where Idguru='$id'");
	$infoA=mysqli_fetch_array($dataA);
	?>
	Nama Anda: <strong><?php echo $infoA['Nama']; ?></strong>
	<br>
	ID Guru: <strong><?php echo $infoA['Idguru']; ?></strong>
	<br>
	Katalaluan: <strong><?php echo $infoA['katalaluan']; ?></strong> </fieldset>
<fieldset>
<table width="800" border="1" align="center">
	<tr><br><center>SENARAI NAMA PELAJAR BERDAFTAR DENGAN ANDA</center>
		<br>
		<td width="40" align="center"><b>Bil.</b></td>
		<td width="100" align="center"><b>Nom KP Pelajar</b></td>
		<td width="100" align="center"><b>Tarikh</b></td>
		<td width="100" align="center"><b>Berat</b></td>
		<td width="100" align="center"><b>Tinggi</b></td>
		<td width="100" align="center"><b>Tindakan</b></td>
<?php

$dataB=mysqli_query($con, "SELECT * FROM bmi WHERE Idguru='$id' ORDER BY Tarikh DESC");
$no=1;
while ($infoB=mysqli_fetch_array($dataB))
{
?>
<tr>

	<td align="center"><?php echo $no;?></td>
	<td align="center"><?php echo $infoB['Idpelajar'];?></td>
	<td align="center"><?php echo $infoB['tarikh'];?></td>
	<td align="center"><?php echo $infoB['berat'];?></td>
	<td align="center"><?php echo $infoB['tinggi'];?></td>
	<td align="center">

		<a href="edit_bmi.php?kemaskini_id=<?php echo $infoB['Idbmi']; ?>">Kemaskini</a> |
		<a href="hapus_bmi.php?hapus_id=<?php echo $infoB['Idbmi']; ?>"
		onclick="return confirm('Anda Pasti?')">Hapus</a> 
	</td>
</tr>
<?php
$no++;//increment
}
?>

</table>
<br>
<center><a href="logout.php"><input type="submit" name="submit" value="LOGOUT"></a> |
<a href="senarai_pelajar.php"><input type="submit" name="submit" value="Senarai Pelajar"></a></center>
</fieldset>
<br />
</center>
</body>
</html>