<?php

require('config.php');


include('pengesahan.php');


$id=$_SESSION['username'];

?>
<html>
<head>
	<title>DASHBOARD PELAJAR</title>
</head>
<body>
<center><h2>DASHBOARD PELAJAR</h2></center>
<fieldset>
<center>
<b>SELAMAT DATANG</b> <br>
	<?php

	$dataA=mysqli_query($con, "select * from pelajar where IDPelajar='$id'");
	$infoA=mysqli_fetch_array($dataA);
	?>	
	Nama Anda:<strong><?php echo $infoA['Nama']; ?></strong><br>
	Nombor KP:<strong><?php echo $infoA['Idpelajar']; ?></strong></br>
<br>
<table width="800" border="1" align="center">
	<tr><center><b>SENARAI REKOD BMI ANDA</b></center>
		<br>
		<td width="40" align="center"><b>BIL.</b></td>
		<td width="100" align="center"><b>Tarikh</b></td>
		<td width="100" align="center"><b>Berat</b></td>
		<td width="100" align="center"><b>Tinggi</b></td>
		<td width="100" align="center"><b>BMI</b></td>
	</tr>

<?php
	$no=1; //Nilai pembilang mula=1

	$dataB=mysqli_query($con, "SELECT * FROM bmi WHERE Idpelajar='$id' ORDER BY Tarikh DESC");
	while ($infoB=mysqli_fetch_array($dataB))
	{

	$kira=mysqli_query($con, "SELECT Berat, Tinggi, ROUND(Berat/((Tinggi/100)*(Tinggi/100))) AS nilaibmi from bmi");
	$kirabmi=mysqli_fetch_array($kira);
?>
	<tr>
		<!-- panggil data ikut lajur -->
		<td align="center"><?php echo $no; ?></td>
		<td align="center"><?php echo $infoB['tarikh']; ?></td>
		<td align="center"><?php echo $infoB['berat']; ?></td>
		<td align="center"><?php echo $infoB['tinggi']; ?></td>
		<td align="center"><?php echo $kirabmi['nilaibmi']; ?></td>
	</td>
</tr>
<?php

$no++;//INCREMENT
}
?>
</table>
<br>
<center><a href="logout.php"><input type="submit" name="submit" value="LOGOUT"></a></center>
<br>
<u><b>RUMUSAN</b></u><br>


<?php
$dataD=mysqli_query($con, "SELECT COUNT(berat) AS berat99 FROM bmi WHERE IDPelajar='$id'");
$infoD=mysqli_fetch_array($dataD);
?> 
Bilangan Rekod:<?php echo $infoD['berat99'];?><br>



<?php
$dataE=mysqli_query($con, "SELECT MAX(Berat), MAX(Tinggi) FROM bmi WHERE IDPelajar='$id'");
$infoE=mysqli_fetch_array($dataE);
?>
Berat maksimum: <?php echo $infoE['MAX(Berat)']." kilogram";?> &
Tinggi maksimum: <?php echo $infoE['MAX(Tinggi)']." meter";?><br>

<?php
$dataE=mysqli_query($con, "SELECT AVG(Berat), AVG(Tinggi) FROM bmi WHERE IDPelajar='$id'");
$infoE=mysqli_fetch_array($dataE);
?>
Purata berat:<?php echo $infoE['AVG(Berat)']." kilogram"; ?> &
Purata tinggi:<?php echo $infoE['AVG(Tinggi)']." meter"; ?> <br>
</fieldset>
</body>
</html>