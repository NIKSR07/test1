<?php

require('config.php');

include('pengesahan.php');

$id = $_GET['hapus_id'];

//hapus rekod BMI semasa
$result = mysqli_query($con, "DELETE FROM bmi WHERE IDBMI=$id");

//Papar mesej jika berjaya hapus
echo "<script>window.location='dashboard.php'</script>";
?>