<?php
require('config.php');
include('pengesahan.php');

if(isset($_POST['update'])){
    

    $idpelajar= htmlspecialchars($_POST['IDPelajar']);
    $nama= htmlspecialchars($_POST['Nama']);
    $jantina= htmlspecialchars($_POST['Jantina']);


    $stmt = $con->prepare("UPDATE pelajar SET Nama=?, Jantina=? WHERE Idpelajar=?");

    $stmt->bind_param("sss", $nama, $jantina, $idpelajar);
    
    if ($stmt->execute()) {
        echo "<script>alert('Maklumat pelajar $idpelajar berjaya dikemaskini.');
        window.location='senarai_pelajar.php'</script>";
    } else {
        echo "<script>alert('RALAT: Kemaskini GAGAL. Sila cuba lagi. Ralat: " . $stmt->error . "');
        window.location='edit_pelajar.php?kemaskini_id=$idpelajar'</script>";
    }
    $stmt->close();
}
?>

<?php


$id = $_GET['kemaskini_id'] ?? null; 

if ($id) {

    $stmt_select = $con->prepare("SELECT Nama, Jantina FROM pelajar WHERE IDPelajar=?");
    $stmt_select->bind_param("s", $id);
    $stmt_select->execute();
    $result = $stmt_select->get_result();

    if ($result->num_rows > 0) {
        $res = $result->fetch_assoc();
        // Paparkan data semasa
        $nama = $res['Nama'];

        $jantina_db = $res['Jantina']; 
    } else {

        echo "<script>alert('RALAT: ID rekod tidak dijumpai.');
        window.location='senarai_pelajar.php'</script>";
        exit;
    }
    $stmt_select->close();
} else {
    // Jika tiada ID dalam URL
    echo "<script>alert('RALAT: Tiada ID kemaskini yang diberikan.');
    window.location='senarai_pelajar.php'</script>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>KEMASKINI MAKLUMAT</title>
</head>
<body>
<center><h2>KEMASKINI MAKLUMAT PELAJAR</h2>
<fieldset>
    
    <form name="form1" method="post" action="edit_pelajar.php">
        <table border="0">
            <tr>
                <td>ID Pelajar</td>
                <td><input type="text" name="IDPelajar" value="<?php echo htmlspecialchars($id); ?>" readonly></td>
            </tr>
            <tr>
                <td>Nama Pelajar</td>
                <td><input type="text" name="Nama" value="<?php echo htmlspecialchars($nama); ?>" required></td>
            </tr>
            <tr>
                <td>Jantina</td>
                <td>
                    <select name="Jantina" required>
                        <option value="<?php echo htmlspecialchars($jantina_db); ?>">
                            <?php 

                                if ($jantina_db == 'L' || $jantina_db == 'Lelaki') {
                                    echo "Lelaki (Semasa)";
                                } else if ($jantina_db == 'P' || $jantina_db == 'Perempuan') {
                                    echo "Perempuan (Semasa)";
                                } else {
                                    echo "Pilihan Semasa: " . htmlspecialchars($jantina_db);
                                }
                            ?>
                        </option>
                        
                        <option value="L">Lelaki</option> 
                        <option value="P">Perempuan</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><input type="submit" name="update" value="Kemaskini"></td>
            </tr>
        </table>
    </form>
    <br>
    <a href="senarai_pelajar.php"><input type="button" value="Senarai Pelajar"></a>
</fieldset>
</center>

</body>
</html>