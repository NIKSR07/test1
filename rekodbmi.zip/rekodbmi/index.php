<?php

require('config.php');

session_start();

if(isset($_SESSION['username'])){
	
	header("Location: index.php");
}

if (isset($_POST['username'])){
	
	$username = $_POST['username'];
	$pass = $_POST['password'];

$sql = "SELECT * FROM guru WHERE IDGuru='$username' AND Katalaluan='$pass'";

	$hasil = mysqli_query($con, $sql);

if (mysqli_num_rows($hasil)){
	$_SESSION['username'] = $username;

	header("Location: dashboard.php");
	}else{

	echo "<script>alert('ID Guru atau Katalaluan yang salah');
		   window.location='index.php'</script>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>SISTEM REKOD BMI PELAJAR</title>
</head>
<body>
<center><h2>SISTEM REKOD BMI PELAJAR</h2>
<i> Gaya hidup yang cergas dan sihat sepanjang hayat</i>
	<fieldset>
		<!-- Papar Jadual -->
		<table width='70%' border=0 align="center">
			<tr bgcolor='#cccccc'>
			<td width="900" align="center">GURU</td>
			<td width="900" align="center">PELAJAR</td>
		</tr>
		<td>
			<!--paper borang login guru-->
		<form method ="POST">
		<p align="center">Login masuk untuk guru</p>
		<center><label for="inputIDGuru">ID Guru</label></center>
		<center><input type="text" name="username" placeholder="ID Guru" required></centre>
		<br>
		<br>
		<center><label for="inputPassword">Katalaluan</label></center>
		<input type="password" name="password"
		id="inputPassword" placeholder="Katalaluan" required>
		<br>
		<br>
		<button type="submit">Login</button><br><br>Jika belum mempunyai ID Guru,
		<a href="register.php">Daftar di sini</a>

	</td>
	<td><p align="center">Login masuk untuk pelajar</p>
		<center><input onclick="location.href='pelajar_login.php'" type="submit" value="Login"></center>
		<br>
		<center><label>untuk membuat semakan rekod BMI</label></center>
	</td>
</tr>
	</form>
	</fieldset>
</center>
</body>
</html>